/* Client-side validation for the enquiry form. */
(function () {
  "use strict";
  var form = document.getElementById("enquiry-form");
  if (!form) return;

  var status = document.getElementById("form-status");
  var msg = form.elements["message"];
  var counter = document.getElementById("message-count");
  var MAX = 500;

  // Each rule returns an error string, or "" when the value is valid.
  var rules = {
    name: function (v) {
      v = v.trim();
      if (!v) return "Please enter your full name.";
      if (v.length < 2) return "Your name must be at least 2 characters.";
      if (!/^[A-Za-zÀ-ɏ][A-Za-zÀ-ɏ\s'’.-]*$/.test(v)) return "Use letters, spaces, hyphens or apostrophes only.";
      return "";
    },
    email: function (v) {
      v = v.trim();
      if (!v) return "Please enter your email address.";
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)) return "Enter a valid email, e.g. name@example.com.";
      return "";
    },
    phone: function (v) { // optional; South African numbers
      v = v.replace(/[\s-]/g, "");
      if (!v) return "";
      if (!/^(0|\+27)[1-9]\d{8}$/.test(v)) return "Enter a valid South African number, e.g. 069 123 4567.";
      return "";
    },
    topic: function (v) { return v ? "" : "Please choose a topic."; },
    message: function (v) {
      v = v.trim();
      if (!v) return "Please write your message.";
      if (v.length < 10) return "Please write at least 10 characters (" + v.length + " so far).";
      if (v.length > MAX) return "Please keep your message under " + MAX + " characters.";
      return "";
    }
  };

  function errEl(field) { return document.getElementById(field.name + "-error"); }

  function setState(field, error) {
    var el = errEl(field);
    if (el) el.textContent = error;
    field.classList.toggle("invalid", !!error);
    field.classList.toggle("valid", !error && field.value.trim() !== "");
    field.setAttribute("aria-invalid", error ? "true" : "false");
  }

  function check(field) {
    var error = rules[field.name] ? rules[field.name](field.value) : "";
    setState(field, error);
    return !error;
  }

  function checkRadios() {
    var chosen = form.querySelector('input[name="contactPref"]:checked');
    document.getElementById("contactPref-error").textContent = chosen ? "" : "Choose how we should reply.";
    return !!chosen;
  }

  function checkConsent() {
    var box = form.elements["consent"];
    document.getElementById("consent-error").textContent = box.checked ? "" : "Please agree so we can respond to you.";
    box.setAttribute("aria-invalid", box.checked ? "false" : "true");
    return box.checked;
  }

  // Live feedback: validate on blur, then re-validate as the user fixes it.
  Object.keys(rules).forEach(function (n) {
    var f = form.elements[n];
    f.addEventListener("blur", function () { check(f); });
    f.addEventListener("input", function () { if (f.classList.contains("invalid")) check(f); });
  });
  form.querySelectorAll('input[name="contactPref"]').forEach(function (r) { r.addEventListener("change", checkRadios); });
  form.elements["consent"].addEventListener("change", checkConsent);

  msg.addEventListener("input", function () {
    var n = msg.value.length;
    counter.textContent = n + " / " + MAX;
    counter.style.color = n > MAX ? "var(--err)" : "";
  });

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    var results = Object.keys(rules).map(function (n) { return check(form.elements[n]); });
    results.push(checkRadios(), checkConsent());
    status.className = "status";
    status.textContent = "";

    if (results.indexOf(false) !== -1) {
      status.className = "status bad";
      status.textContent = "Please fix the highlighted fields and try again.";
      var firstBad = form.querySelector('[aria-invalid="true"]');
      if (firstBad) firstBad.focus();
      return;
    }

    var firstName = form.elements["name"].value.trim().split(" ")[0];
    form.reset();
    counter.textContent = "0 / " + MAX;
    form.querySelectorAll(".valid,.invalid").forEach(function (el) { el.classList.remove("valid", "invalid"); });
    // No sending service is connected (same as the main site), so we only confirm validation.
    status.className = "status ok";
    status.textContent = "Thank you, " + firstName +
      ". Your enquiry passed validation. Note: this demo form is not connected to a sending service, " +
      "so nothing has been sent. Please phone or WhatsApp 069 173 6005 to reach the Forum.";
  });

  form.addEventListener("reset", function () {
    form.querySelectorAll(".error").forEach(function (el) { el.textContent = ""; });
    status.className = "status";
    status.textContent = "";
  });
})();
